import { Action } from '@ngrx/store';

export const LOG_REQUEST: string = '[Log] LOG REQUEST ..';
export const ADD_LOG: string = '[Log] ADD LOG';
export const LOG_SUCCESS: string = '[Log] LOG Success';
export const LOG_FAIL: string = '[Log] LOG Fail';
export const SAVE_LOGS: string = '[Log] SAVE LOGS';

// tslint:disable-next-line: max-classes-per-file
export class LogRequest implements Action {
  readonly type: string = LOG_REQUEST;
}

// tslint:disable-next-line: max-classes-per-file
export class SaveLogSS implements Action {
  readonly type: string = SAVE_LOGS;
  constructor(public payload: Array<any>) {}
}

// tslint:disable-next-line: max-classes-per-file
export class AddLog implements Action {
  readonly type: string = ADD_LOG;
  constructor(public payload: any) {}
}

// tslint:disable-next-line: max-classes-per-file
export class CopyLog implements Action {
  readonly type: string = 'COPY_LOG';
  constructor(public payload: any) {}
}

//
// // tslint:disable-next-line: max-classes-per-file
// export class LoadLogSuccess implements Action {
//   public readonly type: string = LOG_SUCCESS;
//   public constructor(public payload: Log) {}
// }
//
// // tslint:disable-next-line: max-classes-per-file
// export class LoadLogFail implements Action {
//   public readonly type: string = LOG_FAIL;
//   public constructor(public payload: Error) {}
// }


export type LogActions
  = AddLog
  // | LoadLogSuccess
  // | LoadLogFail
  | SaveLogSS
  ;
