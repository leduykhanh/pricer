import { LogActions } from '../actions/logs.action';
import { LogRow } from '../../ui/log-table/log-row';

export const initialState = {
  data: [new LogRow(), new LogRow(), new LogRow(), new LogRow(), new LogRow(),
    new LogRow(), new LogRow(), new LogRow(), new LogRow(), new LogRow()],
  copiedRow: null
};

export function logReducer(state = initialState, action: LogActions) {
  switch (action.type) {
    case 'ADD_LOGS':
      const newStateData = [].concat(state.data);
      newStateData.push(action.payload);
      return {...state, data: newStateData };

    case '[Log] SAVE LOGS':
      return action.payload;

    case 'COPY_LOG':
      return {...state, copiedRow: action.payload };

    default:
      return state;
  }
}
