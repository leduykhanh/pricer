import { logReducer } from './logs.reducer';

export const reducers = {
  logs: logReducer
}
