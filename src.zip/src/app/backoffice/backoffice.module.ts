import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { BackofficeComponent } from './backoffice.component';


import { backofficeRoutes } from './routes';

@NgModule({
  declarations: [BackofficeComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(backofficeRoutes),
  ]
})
export class BackofficeModule { }
