import { BackofficeComponent } from './backoffice.component';
import { Routes } from '@angular/router';
// import { DashboardComponent } from './dashboard/dashboard.component';

export const backofficeRoutes: Routes = [
  {
    path: '',
    component: BackofficeComponent,
    children: [
      { path: '', redirectTo: 'swaption-page', pathMatch: 'full' },
      { path: 'swaption-page', loadChildren: './swaption-page/swaption-page.module#SwaptionPageModule' },
    ]
  }
];
