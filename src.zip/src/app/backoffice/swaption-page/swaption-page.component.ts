import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';

import { LogRow } from '../../ui/log-table/log-row';
import { SwaptionRow } from '../../ui/swaption-table/swaption-row';
import * as Actions from '../../store/actions';

@Component({
  selector: 'app-swaption-page',
  templateUrl: './swaption-page.component.html',
  styleUrls: ['./swaption-page.component.scss']
})
export class SwaptionPageComponent implements OnInit {
  logData: LogRow[] = [];
  constructor(
    private _store: Store<any>
  ) { }

  ngOnInit() {
    this.logData.push(new LogRow());
    // console.log(Actions.SaveLogSS)
  }

  onSaveToLog(swaption: SwaptionRow) {
    // console.log('adding to log')
    this.logData.push(new LogRow(swaption));
  }

  loadLog() {
    this._store.subscribe( s => this.logData = s.logs.data );
  }

  onSaveLog() {
    this._store.dispatch(new Actions.SaveLogSS(this.logData) );
  }

  onCopyLog(logRow) {
    this._store.dispatch(new Actions.CopyLog(logRow) );
  }


}
