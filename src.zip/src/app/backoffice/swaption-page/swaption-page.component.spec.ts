import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwaptionPageComponent } from './swaption-page.component';

describe('SwaptionPageComponent', () => {
  let component: SwaptionPageComponent;
  let fixture: ComponentFixture<SwaptionPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwaptionPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwaptionPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
