import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { swaptionRoutes } from './routes';
import { SwaptionPageComponent } from './swaption-page.component';
import { UiModule } from '../../ui/ui.module';

@NgModule({
  declarations: [SwaptionPageComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(swaptionRoutes),
    UiModule,
  ]
})
export class SwaptionPageModule { }
