import { Routes } from '@angular/router';
import { SwaptionPageComponent } from './swaption-page.component';

export const swaptionRoutes: Routes = [
  {
    path: '',
    component: SwaptionPageComponent,
  }
];
