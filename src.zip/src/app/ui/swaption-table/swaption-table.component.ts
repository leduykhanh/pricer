import { Component, OnInit, ViewChild, Input, Output,
  EventEmitter, HostListener, Directive } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { Store } from '@ngrx/store';

import * as Actions from '../../store/actions';
import * as Handsontable from 'handsontable';
import { HotTableRegisterer } from '@handsontable/angular';
import { SwaptionRow } from './swaption-row';

// @Directive({
//   selector: '[test-directive]'
// })
// export class TestDirective {
//   @HostListener('keydown', ['$event'])
//   onKeyDown(e) {
//     if (e.shiftKey && e.keyCode) {
//       console.log('shift and L', e.keyCode);
//     }
//   }
// }

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}


 const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'}
];

@Component({
  selector: 'app-swaption-table',
  templateUrl: './swaption-table.component.html',
  styleUrls: ['./swaption-table.component.scss']
})
export class SwaptionTableComponent implements OnInit {
  private hotRegisterer = new HotTableRegisterer();
  private table: any;
  dataset: SwaptionRow[] = [];
  types: string[] = ['Payer', 'Receiver', 'Straddle'];

  @Input()
  id:string;

  @Input()
  name:string;

  @Output()
  onSaveToLog:EventEmitter<SwaptionRow> = new EventEmitter<SwaptionRow>();

  @HostListener('keydown', ['$event'])
  onKeyDown(e) {
    // console.log(e)

    if (e.ctrlKey && e.key == "l" ) {
      e.preventDefault();
      this.addLog();
    }

    if (e.ctrlKey && e.key == "v" ) {
      e.preventDefault();
      this.pasteLog();
    }
  }

  currentRow: SwaptionRow;

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol', 'price'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private _store: Store<any>
  ) { }

  ngOnInit() {
    this.dataset.push(new SwaptionRow());
    this.dataSource.sort = this.sort;

    //  console.log(this.hotRegisterer.getInstance(this.id))
    // console.log("this.table", this.table);
  }

  applyFilter(filterValue: string) {
    // this.dataSource.filter = filterValue.trim().toLowerCase();
    this.table = this.hotRegisterer.getInstance(this.id);
    var search = this.table.getPlugin('search');
    var queryResult = search.query(filterValue);

    // console.log(queryResult);
    this.table.render();
  }

  addRow() {
    // this.dataset.push(new SwaptionRow());
    // this.hotRegisterer.getInstance(this.id).loadData([['new', 'data']]);
    // console.log(this.hotRegisterer.getInstance(this.id))
    this.table = this.hotRegisterer.getInstance(this.id);
    this.table.alter('insert_row', this.table.countRows(), 1);
  }

  pasteLog() {
    //

    this._store.subscribe( s =>
      {
        if(s.logs.copiedRow == null) return alert("no log copied");
        this.addRow();
        this.table = this.hotRegisterer.getInstance(this.id);
        const selected = (this.table.getSelected());
        const lastIndex = this.table.countRows() - 1;
        [].concat(s.logs.copiedRow.toArray()).map(
          (v, i) => {
            if (i == 2) {
              // v = false;
              this.table.setDataAtCell(lastIndex, i , false, "populate")
            }
            this.table.setDataAtCell(lastIndex, i >= 2 ? i+1: i , v, "populate")
          }
        )
        // this.table.setDataAtCell(this.table.countRows() - 1, 3, s.logs.copiedRow.ccy, "populate") ;
      }
    );
  }

  addLog() {
    this.table = this.hotRegisterer.getInstance(this.id);
    const selected = (this.table.getSelected());
    // console.log(selected, selected[0])
    // console.log("this.table.getDataAtRow(selected[0]))",this.table.getDataAtRow(selected[0][0]));
    selected && selected.length > 0 && this.onSaveToLog.emit(new SwaptionRow(this.table.getDataAtRow(selected[0][0])));
  }

  afterChange(hot, changes, src) {
    // console.log(src);
    changes && (src == 'edit') && changes.forEach(([row, prop, oldValue, newValue]) => {
      if (oldValue !== newValue){
        const rowRecord = new SwaptionRow(hot.getDataAtRow(row));
        rowRecord.calculate();
        const rowRecordArray = rowRecord.toArray();
        rowRecordArray.map(
          (v, i) => {
            if(i > 14) hot.setDataAtCell(row, i, v, 'populate');
          }
        );
      }
      // console.log(hot.getDataAtRow(row));
    });
  }

  rowRendering(instance, td, row, col, prop, value, cellProperties) {
    console.log("Rendering row ");
    Handsontable.renderers.TextRenderer.apply(this, arguments);
    if(row % 2 == 0) {
        td.style.backgroundColor = '#F5F5F5';
    } else {
        td.style.backgroundColor = 'white';
    }
  }

  renderStrike(instance, td, row, col, prop, value, cellProperties){
    // Handsontable.renderers.TextRenderer.apply(this, arguments);
    td.innerHTML = "@" + (value?value:'');
    return td;
  }

  renderNegative(instance, td, row, col, prop, value, cellProperties){
    // Handsontable.renderers.TextRenderer.apply(this, arguments);
    td.innerHTML = `<span class="${value > 0 ? '' : 'red-text' }">${value?value:''}</span>`;
    td.classList.add("htDimmed");
    return td;
  }

  renderPercentage(instance, td, row, col, prop, value, cellProperties){
    // Handsontable.renderers.TextRenderer.apply(this, arguments);
    td.innerHTML = (value?value:'') + "%";
    td.classList.add("htDimmed");
    return td;
  }

}
