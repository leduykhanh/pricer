/* tslint:disable */
export class SwaptionRow {
  ir: number = 0; //0
  vol: number = 0; //1
  price: boolean = false; //2
  ccy: string = "SAR";//3
  exp: string = "1y";//4
  tenor: string = "1y";//5
  type: string = "Straddle";//6
  strike: number = 1;//7
  funding: string = "USD.FEDFUND";//8
  fix: number = 1;//9
  flow: number = 1;//10
  dcFix: string = "ACT/360";//11
  dcFlow: string = "ACT/360";//12
  bid: number = 1;//13
  offer: number = 1;//14
  pv: number = 0;//15
  normalVol: number = 0;//16
  midBidVol: number = 0;//17
  midOfferVol: number = 0;//18
  vegaBid: number = 0;//19
  vegaOffer: number = 0;//20
  delta: number = 0;//21
  fpcVega: number = 0;//22

  constructor(data?:Array<any>){
    if (data && data.length > 0){
      console.log("data", data);
      // this.ir = data[0];
      // this.vol = data[1];
      // this.price = data[2];
      // this.ccy = data[3];
      // this.type = data[6];
      // this.pv = data[15];
      Object.keys(this).map(
        (key, index) => {
          if (data[index] != null)   this[key] = data[index] ;
        }
      )
    }

    this.calculate();

  }

  calculate() {
    this.normalVol = parseFloat(Math.random().toFixed(2));
    this.midBidVol = parseFloat(Math.random().toFixed(2));
    this.midOfferVol = parseFloat(Math.random().toFixed(2));
    this.pv = parseFloat((1000 * Math.random()).toFixed(1));
    this.vegaBid = parseFloat((10*(0.5 - Math.random())).toFixed(1));
    this.vegaOffer = parseFloat((10*(0.5 - Math.random())).toFixed(1));
    this.delta = parseFloat((10*(0.5 - Math.random())).toFixed(1));
  }

  toArray(): Array<any> {
    return Object.values(this);
  }
}
