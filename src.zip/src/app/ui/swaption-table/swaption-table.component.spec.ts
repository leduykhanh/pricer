import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SwaptionTableComponent } from './swaption-table.component';

describe('SwaptionTableComponent', () => {
  let component: SwaptionTableComponent;
  let fixture: ComponentFixture<SwaptionTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwaptionTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwaptionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
