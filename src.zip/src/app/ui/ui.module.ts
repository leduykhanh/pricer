import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatFormFieldModule } from '@angular/material';
import { HotTableModule } from '@handsontable/angular';

import { SwaptionTableComponent } from './swaption-table/swaption-table.component';
import { LogTableComponent } from './log-table/log-table.component';

@NgModule({
  declarations: [SwaptionTableComponent, LogTableComponent],
  imports: [
    CommonModule,
    MatTableModule,
    MatFormFieldModule,
    HotTableModule,
  ],
  exports: [
    SwaptionTableComponent,
    LogTableComponent
  ]
})
export class UiModule { }
