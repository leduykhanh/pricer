/* tslint:disable */

import { SwaptionRow } from '../swaption-table/swaption-row';
const currencies = ["VND", "SGD", "CNY", "USD", "MYR","EUR", "BAH", "SAR"];
export class LogRow {
  ir: number = 0;
  vol: number = 0;
  ccy: string = "SAR";
  exp: string = "1y";
  tenor: string = "1y";
  type: string = "Straddle";
  strike: number = 1;
  funding: string = "USD.FEDFUND";
  fix: number = 1;
  flow: number = 1;
  dcFix: string = "ACT/360";
  dcFlow: string = "ACT/360";
  bid: number = 1;
  offer: number = 1;
  pv: number = 0;
  normalVol: number = 0;
  midBidVol: number = 0;
  midOfferVol: number = 0;
  vegaBid: number = 0;
  vegaOffer: number = 0;
  delta: number = 0;
  fpcVega: number = 0;

  constructor(swaption?:SwaptionRow) {
    if(swaption) {
      // console.log("type", swaption["type"], swaption);
      for(let keyT in this){
        // console.log("key", key, swaption.hasOwnProperty(key))
        const key: any = keyT;
        if (swaption.hasOwnProperty(key)) {
          this[key] = swaption[key] as any;// @ts-ignore
        }
      }
    }
    else {
      this.ccy = currencies[Math.floor(currencies.length*Math.random())];
      this.exp = Math.floor(10*Math.random()) + 'y';
      this.tenor = Math.floor(10*Math.random()) + 'y';
      this.normalVol = parseFloat(Math.random().toFixed(2));
      this.midBidVol = parseFloat(Math.random().toFixed(2));
      this.midOfferVol = parseFloat(Math.random().toFixed(2));
      this.pv = parseFloat((1000 * Math.random()).toFixed(1));
      this.vegaBid = parseFloat((10*(0.5 - Math.random())).toFixed(1));
      this.vegaOffer = parseFloat((10*(0.5 - Math.random())).toFixed(1));
    }
  }

  toArray(): Array<any> {
    return Object.values(this);
  }

}
