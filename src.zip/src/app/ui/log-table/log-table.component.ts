import { Component, OnInit, Input, EventEmitter, Output, HostListener } from '@angular/core';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { HotTableRegisterer } from '@handsontable/angular';

import { LogRow } from './log-row';
import { SwaptionRow } from '../swaption-table/swaption-row';

@Component({
  selector: 'app-log-table',
  templateUrl: './log-table.component.html',
  styleUrls: ['./log-table.component.scss']
})
export class LogTableComponent implements OnInit {

  timeUpdated: Date = new Date();
  contextMenu = ['copy']

  @Input()
  logData: LogRow[];

  @Input()
  id:string;

  @Output()
  loadLog:EventEmitter<boolean> = new EventEmitter<boolean>();

  @Output()
  onSaveLog:EventEmitter<boolean> = new EventEmitter<boolean>();

  @Output()
  onCopyLog:EventEmitter<LogRow> = new EventEmitter<LogRow>();

  private toasterService: ToasterService;
  private hotRegisterer = new HotTableRegisterer();
  private table: any;

  constructor(toasterService: ToasterService) {
        this.toasterService = toasterService;
    }

  ngOnInit() {
    // this.logData.push(new LogRow());
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(e) {
    // console.log(e)
    if (e.ctrlKey && e.key == "c" ) {
      this.copyLog()
    }
  }

  actionLoadLog(){
    this.loadLog.emit(true);
  }

  applyFilter(filterValue: string) {
    // this.dataSource.filter = filterValue.trim().toLowerCase();
    this.table = this.hotRegisterer.getInstance(this.id);
    var search = this.table.getPlugin('search');
    var queryResult = search.query(filterValue);

    this.table.render();
  }

  saveLog(){
    this.onSaveLog.emit(true);
    this.toasterService.pop('success', 'Success', 'Logs was saved');
  }

  renderNegative(instance, td, row, col, prop, value, cellProperties){
    // Handsontable.renderers.TextRenderer.apply(this, arguments);
    td.innerHTML = `<span class="${value > 0 ? '' : 'red-text' }">${value?value:''}</span>`;
    return td;
  }

  copyLog(){
    this.table = this.hotRegisterer.getInstance(this.id);
    const selected = (this.table.getSelected());
    // console.log(selected, selected[0])
    // console.log("this.table.getDataAtRow(selected[0]))",this.table.getDataAtRow(selected[0][0]));
    selected && selected.length > 0 && this.onCopyLog.emit(
      new LogRow(new SwaptionRow([0,0,false].concat(this.table.getDataAtRow(selected[0][0]))))
    );
    this.toasterService.pop('info', 'Success', 'Row was copied');
  }

}
