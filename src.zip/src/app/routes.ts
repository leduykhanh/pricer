import { Routes } from '@angular/router';
// import { LoginComponent } from './login/login.component';
import { NotfoundComponent } from './notfound/notfound.component';
// import { AuthGuardService } from './services/auth/auth-guard.service';
// import BackofficeModule from './backoffice/backoffice.module';

export const appRoutes: Routes = [
  {
    path: '', redirectTo: 'backoffice', pathMatch: 'full'
  },
  // {
  //   path: 'login',
  //   component: LoginComponent,
  //   canActivate: [AuthGuardService]
  // },
  {
    path: 'backoffice',
    loadChildren: './backoffice/backoffice.module#BackofficeModule',
    // canActivate: [AuthGuardService]
  },
  {
    path: '**',
    component: NotfoundComponent
  }
];
